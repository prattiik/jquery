function MakeQuiz(){
    const output = [];

    Quiz_questions.forEach(
        (currentQuestion, questionNumber) => {

        const answers = [];
        if (questionNumber===0){
            var diff_type = "radio";
        }
        if(questionNumber===1){
            var diff_type = "checkbox";
        }

        for(letter in currentQuestion.answers){
            
            answers.push(
            `<label>
                <input type="${diff_type}" name="question${questionNumber}" value="${letter}">
                ${letter} :
                ${currentQuestion.answers[letter]}
            </label>`
            );
        }

        output.push(
            `<div class="question"> ${currentQuestion.question} </div>
            <div class="answers"> ${answers.join('')} </div>`
        );
        }
    );

    Quiz_que_ans.innerHTML = output.join('');
}

function showQuizResults(){
    const answerContainers = Quiz_que_ans.querySelectorAll('.answers');

    let correct_answers = 0;
    var first_ans = "";
    var checked_box = 0;
    Quiz_questions.forEach( (currentQuestion, questionNumber) => {

        console.log(questionNumber)

        if (questionNumber === 0){
            const answerContainer = answerContainers[questionNumber];
            const selector = `input[name=question${questionNumber}]:checked`;
            const userAnswer = (answerContainer.querySelector(selector) || {}).value;
            if(userAnswer === currentQuestion.correctAnswer){
                correct_answers++;
                first_ans="correct";
                answerContainers[questionNumber].style.color = 'lightgreen';
            }
            else{
                answerContainers[questionNumber].style.color = 'red';
            }
        }else if (questionNumber === 1){
             const answerContainer = answerContainers[questionNumber];
             const selector = `input[name=question${questionNumber}]:checked`;
             const userAnswer = (answerContainer.querySelector(selector) || {}).value;
             var checked = document.querySelectorAll(selector);
             checked_box = checked;
             let correct_answersques1 = 0;

            if (checked.length === 0) {
                answerContainers[questionNumber].style.color = 'red';
                return;
            } else {
                $.each(currentQuestion.correctAnswer, function(index, value){
                    console.log(index + ' ' + value);
                    correct_answersques1++;
                 });

                    if(correct_answersques1 === 4){
                        correct_answers++;
                        answerContainers[questionNumber].style.color = 'lightgreen';
                        //  Correct_count.innerHTML = "Almost There";
                    }
                    else if(correct_answersques1 === 1){
                        correct_answers++;
                        answerContainers[questionNumber].style.color = 'lightgreen';
                       //  Correct_count.innerHTML = "Almost There";
                    }
                    else if(correct_answersques1 === 2){
                       correct_answers++;
                       // color the answers green
                       answerContainers[questionNumber].style.color = 'lightgreen';
                       // Correct_count.innerHTML = "Almost There";
                   }
                   else if(correct_answersques1 === 3){
                       correct_answers++;
                       answerContainers[questionNumber].style.color = 'lightgreen';
                       // Correct_count.innerHTML = "Almost There";
                   }
            }     
        } 
    });
   
    if (first_ans === "correct"){
        firstqueContainer.innerHTML = "First question answer is correct";
    }
    else{
        firstqueContainer.innerHTML = "First question answer is wrong";
    }
    
    Correct_count.innerHTML = `${correct_answers} out of ${Quiz_questions.length}`;
}

const Quiz_que_ans = document.getElementById('quiz');
const Correct_count = document.getElementById('results');
const firstqueContainer = document.getElementById('first_que')
const secqueContainer = document.getElementById('sec_que');
const Submit_button = document.getElementById('submit');

const Quiz_questions = [
    {
      question: "Where would you find the Empire State building?",
      answers: {
        a: "New York",
        b: "Los Angeles",
        c: "San Francisco",
        d: "New Orleans"
      },
      correctAnswer: "a"
    },
    {
        question: "Identify the components of a PC",
        answers: {
          a: "Processor",
          b: "Memory",
          c: "Hard Disk",
          d: "CD-ROM Drive",
          e: "Printer"
        },
        correctAnswer: ["a","b","c","d"]
      },
];

MakeQuiz();

Submit_button.addEventListener('click', showQuizResults);

